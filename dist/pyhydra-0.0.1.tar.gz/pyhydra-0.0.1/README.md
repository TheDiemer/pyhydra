# pyhydra

Python API for Hydra (CEE Case API)

Backing Library for https://gitlab.cee.redhat.com/erich/pyhydra-cli


## Building pyhydra

To build pyhydra run: 

```
pipenv run python setup.py sdist bdist_wheel
``` 
