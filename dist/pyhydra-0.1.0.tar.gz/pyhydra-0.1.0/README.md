# pyhydra

Python API for Hydra (CEE Case API)
RestAPI Docs: https://access.redhat.com/hydra/rest/api-docs

# Where this libarary is used: 

- Backing Library for https://github.com/TheDiemer/pyhydra-cli


## Building pyhydra

To build pyhydra run: 

```
pipenv run python setup.py sdist bdist_wheel
``` 
